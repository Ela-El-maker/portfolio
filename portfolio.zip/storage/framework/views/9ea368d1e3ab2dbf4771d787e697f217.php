<section class="service-area section-padding-top" id="about-page">
    <div class="container">
     <div class="row">
             <div class="col-lg-6 offset-lg-3 text-center">
                 <div class="section-title">
                     <h3 class="title"><?php echo e($serviceTitle->title); ?></h3>
                     <div class="desc">
                         <p><?php echo e($serviceTitle->sub_title); ?></p>
                     </div>
                 </div>
             </div>
         </div>
        <div class="row">

            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 <?php echo e($loop->index > 2 ? 'mt-4' : ''); ?>">
                    <div class="single-service">
                        <h3 class="title wow fadeInRight" data-wow-delay="0.3s"><?php echo e($service->name); ?></h3>
                        <div class="desc wow fadeInRight" data-wow-delay="0.4s">
                            <p><?php echo e($service->description); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>
    </div>
</section>
<?php /**PATH C:\laragon\www\portfolio\resources\views/frontend/sections/service.blade.php ENDPATH**/ ?>