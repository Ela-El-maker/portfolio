<?php
    $footerInfo = \App\Models\FooterInfo::first();
    $footerSocial = \App\Models\FooterSocialLink::all();
    $footerContact = \App\Models\FooterInfoContact::first();
    $footerUsefuls =  \App\Models\FooterUsefulLinks::all();
    $footerHelps =  \App\Models\FooterHelpLinks::all();

?>

<!-- Footer-Area-Start -->
<footer class="footer-area">
    <div class="container">
        <div class="row footer-widgets">
            <div class="col-md-12 col-lg-3 widget">
                <div class="text-box">
                    <figure class="footer-logo">
                        <img src="<?php echo e(asset($generalSetting->footer_logo)); ?>" alt="">
                    </figure>
                    <p><?php echo e($footerInfo->info); ?></p>
                    <ul class="d-flex flex-wrap">
                        <?php $__currentLoopData = $footerSocial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e($social->url); ?>"><i class="<?php echo e($social->icon); ?>"></i></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                    </ul>
                </div>
            </div>
            <div class="col-md-4 col-lg-2 offset-lg-1 widget">
                <h3 class="widget-title">Useful Link</h3>
                <ul class="nav-menu">
                    <?php $__currentLoopData = $footerUsefuls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footerUseful): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e($footerUseful->url); ?>"><?php echo e($footerUseful->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    
                </ul>
            </div>
            <div class="col-md-4 col-lg-3 widget">
                <h3 class="widget-title">Contact Info</h3>
                <ul>
                    <li><?php echo e($footerContact->address); ?></li>
                    <li><a href="javascript:void(0)"><?php echo e($footerContact->phone); ?></a></li>
                    <li><a href="javascript:void(0)"><?php echo e($footerContact->email); ?></a></li>
                </ul>
            </div>
            <div class="col-md-4 col-lg-3 widget">
                <h3 class="widget-title">Help</h3>
                <ul class="nav-menu">
                    <?php $__currentLoopData = $footerHelps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footerHelp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e($footerHelp->url); ?>"><?php echo e($footerHelp->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                   
                </ul>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="copyright">
                        <p>Copyright <?php echo e(date('Y', strtotime($footerInfo->created_at))); ?> <span><?php echo e($footerInfo->copyright); ?></span>. All Rights Reserved.</p>
                        <p>Powered by <?php echo e($footerInfo->copyright); ?> &nbsp; | &nbsp; <?php echo e(date('d M, Y', strtotime($footerInfo->created_at))); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer-Area-End --><?php /**PATH C:\laragon\www\portfolio\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>