 <section class="service-area section-padding-top" id="about-page">
     <div class="container">
         <div class="row">
             <div class="col-lg-6 offset-lg-3 text-center">
                 <div class="section-title">
                     <h3 class="title"><?php echo e($personalTitle->title); ?></h3>
                     <div class="desc">
                         <p><?php echo e($personalTitle->sub_title); ?></p>
                     </div>
                 </div>
             </div>
         </div>
         <div class="row">
             <?php $__currentLoopData = $personalGrowth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="col-lg-4 <?php echo e($loop->index > 2 ? 'mt-4' : ''); ?>">
                     <div class="single-service" data-target-date="<?php echo e($personal->dueDate); ?>">
                         <h3 class="title wow fadeInRight" data-wow-delay="0.3s"><?php echo e($personal->name); ?></h3>
                         <div class="desc wow fadeInRight" data-wow-delay="0.4s">
                             <p><?php echo e($personal->description); ?></p>
                             <p class="poetic-description">Start by: <?php echo e($personal->startDate); ?></p>
                             <p class="poetic-description">Due by: <?php echo e($personal->dueDate); ?></p>

                         </div>

                     </div>
                 </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </div>
     </div>
 </section>
<?php /**PATH C:\laragon\www\portfolio\resources\views/frontend/sections/personal-program.blade.php ENDPATH**/ ?>