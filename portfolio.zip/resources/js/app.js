import './bootstrap';

// import 'laravel-datatables-vite';

import 'https://cdn.datatables.net/2.0.8/js/dataTables.min.js';

import 'https://cdn.datatables.net/2.0.8/js/dataTables.bootstrap5.min.js';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
