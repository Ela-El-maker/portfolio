"use strict";

var simple_map = new GMaps({
  div: '#simple-map',
  lat: -6.5637928,
  lng: 106.7535061
})
